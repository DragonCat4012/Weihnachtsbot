On this site you will learn how to use our API

**Installation**:
To install our API, just type the following sentence in your console:

```npm i discord-botlist-api```

**How to use it**:
For a tutorial, please visit [https://docs.discord-botlist.eu](our Documentation)
